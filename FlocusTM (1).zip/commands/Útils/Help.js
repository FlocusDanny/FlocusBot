module.exports = {
name: "$alwaysExecute",
code: `$onlyIf[$commandInfo[$replaceText[$splitText[2];$;];name]!=;{title:**Comando inexistente**}{color:00F4FF}{description:
<:x_:833858832332619806> **|** O comando\`$ReplaceText[$message[1];/f; ]\` e inexistente. Verifique meus comandos em \`$getServerVar[prefix]ajuda\`

<:pin:833858827106648104> **|** Verifique se você digitou o comando corretamente.}]
$textSplit[$message[1];$getServerVar[prefix]]
$onlyIf[$stringStartsWith[$message[1];$getServerVar[prefix]]!=false;]`,
}
