module.exports = {
  name: "eval",
  code: `
  $title[**$username[$clientID] | Eval**]
  $description[<:entrada:834099665128390696>** » Entrada :**
$message
<:saida:834099664877125662>** » Saida :**
$eval[$message;yes]]
  $color[00F4FF]
  $onlyForIDs[$botOwnerID;{title:**Mensagem de erro**}{description:
<:x_:833858832332619806> **|** Você não pode usar esse comando, e restrito.

<:pin:833858827106648104> **|** Apenas meu Criador pode utilizar esse comando.}{color:00F4FF}]
  `
}