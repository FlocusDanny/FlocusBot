module.exports = {
  nonPrefixed: true,
  name: "<@!833792696631951362>",
  aliases: ['<@833792696631951362>','$username[833792696631951362]'],
  code: `
  $title[<:Flocos:833821190664749077>** » $username[$clientID] Apresentação**]
  $description[> **Olá \`$username\`, eu me chamo \`Flocus™\`, Uma bot multifuncional para ajudar na diversão  e administração do servidor. Me adicione no seu [Servidor](https://discord.com/oauth2/authorize?client_id=833792696631951362&scope=bot%20applications.commands&permissions=2147483647), é caso tenha dúvidas venha conhecer meu servidor de [suporte](https://discord.gg/k4Gcdmwx6s). Utilize \`$getServerVar[prefixo]ajuda\` para ver meus comandos.**]
$color[00F4FF]
$thumbnail[$userAvatar[$clientID]]
  `
}