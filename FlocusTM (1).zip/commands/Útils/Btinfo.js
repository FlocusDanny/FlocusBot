module.exports = {
  name: "botinfo",
  code: `
  $title[**$username[$clientID] | Informações**]
  $addField[**Hospedagem**;
<:ping:834181779350224916>** » Ping :** \`$Pingms\`
<:data:834181766851461120> **» Uptime :** \`$uptime\`
<:nuvem:834181785407455232>** » Cpu :** \`$cpu% | 100%\`
<:memory:834181781947023360>** » Ram :** \`$rammb | 500mb\`]

$addField[**Status**;
<:flag:834181774241169438>** » Servidores :** \`$serverCount\`
<:users:834181871184773140>** Usuários :** \`$allMembersCount\`
<:__:834181776545021962>** » Canais :** \`$allChannelsCount\`]

$addField[**Criação**;
<:data1:834181771658526781>** » Criada em :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$formatDate[$creationDate[$clientID];DD de MMMM YYYY];December;Dezembro de;-1];January;Janeiro de;-1];February;Fevereiro de;-1];March;Março de;-1];April;Abril de;-1];May;Maio de;-1];June;Junho de;-1];July;Julho de;-1];August;Agosto de;-1];September;Setembro de;-1];October;Outubro de;-1];November;Novembro de;-1]\`
<:data:834181766851461120>** » Criada há :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$creationDate[$clientID;time];months;mêses];weeks;semanas];month;mês];days;dias];hours;horas];minutes;minutos];and;é];seconds;segundos];week;semana];day;dia];hour;hora];minute;minuto];second;segundo]\`
$timezone[America/Sao_Paulo]]

$addField[**Desenvolvida**;
<:frasco:834181876263419954>** » Biblioteca :** \`DBD.JS ($packageVersion)\`
<:js:834181879027728404>** » Linguagem :** \`Javascript\`
<:web:834181765974327327>** » Plataforma :** \`Repl.it\`]

$addField[**Principais**;
<:cafe:834181872756981820>** » Criador :** \`$usertag[$botOwnerID]\`
<:users:834181871184773140>** » Nome :** \`$username[$clientID]\`
<:id:834181873944756245>** » ID :** \`$clientID\`]
$color[00F4FF]
$Thumbnail[$userAvatar[$clientID]]
  `
}