module.exports = {
  name: "serverinfo",
  code: `
  $title[**$serverName | Informações**]
  $thumbnail[$servericon]
  $color[00F4FF]
  $addField[**Status**;
**<:region:834771667225542676> » Região :** \`$serverRegion\`
<:emoji:834771664994041866>** » Emojis :** \`$emojiCount\`
**<:users:834181871184773140> » Usuários :** \`$membersCount\`
**<:__:834181776545021962> » Canais :** \`$channelCount\`]

$addField[**Criação**;
<:data1:834181771658526781>** » Criada em :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$formatDate[$CreationDate[$guildID];DD de MMMM YYYY];December;Dezembro de;-1];January;Janeiro de;-1];February;Fevereiro de;-1];March;Março de;-1];April;Abril de;-1];May;Maio de;-1];June;Junho de;-1];July;Julho de;-1];August;Agosto de;-1];September;Setembro de;-1];October;Outubro de;-1];November;Novembro de;-1]\`
<:data:834181766851461120>** » Criada há :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$creationDate[$guildID;time];years;anos];year;ano];months;mêses];weeks;semanas];month;mês];days;dias];hours;horas];minutes;minutos];and;é];seconds;segundos];week;semana];day;dia];hour;hora];minute;minuto];second;segundo]\`]

$addField[**Posse**;
<:cafe:834181872756981820>** » Dono :** \`$usertag[$ownerID]\`
<:id:834181873944756245>** » ID :** \`$ownerID\`
]
`
}