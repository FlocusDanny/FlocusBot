module.exports = {
  name: "set-prefix",
  code: `
  $title[**Mudando prefixo**]
  $description[<:pin:833858827106648104> **» O meu prefixo nesse servidor foi alterado para :** \`$message[1]\`]
  $color[00F4FF]
  $setServerVar[prefix;$message[1]]
  $setServerVar[prefixo;$message[1]]
  $onlyIf[$message[1]!=;{title:**Mensagem de erro**}{description:
<:x_:833858832332619806> **|** O prefixo fornecido e inválido.
  
<:pin:833858827106648104> **|** Tente colocar um prefixo válido. Exemplo : \`F!\`}{color:00F4FF}]

$onlyPerms[admin;{title:**Mensagem de erro**}{description:
<:x_:833858832332619806> **|** Você não possui, permissão o suficiente para executar esse comando.

<:pin:833858827106648104> **|** Para utilizar esse comando você precisa da permissão : \`Administrador\`}{color:00F4FF}]
  `
}