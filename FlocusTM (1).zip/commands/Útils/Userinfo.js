module.exports = {
  name: "userinfo",
  code: `
  $color[00F4FF]
  $thumbnail[$userAvatar[$mentioned[1;yes]]]
  $title[**$username[$mentioned[1;yes]] | Informações**]
  
  $addField[**Permissões**;
  \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$userPerms[$mentioned[1;yes]];Create Instant Invite;Criar Convite Instantâneo];Kick Members;Kickar Membros];Ban Members;Banir Membros];Administrator;Administrador];Manage Channels;Gerenciar Canais];Manage Guild;Gerenciar Servidor];Add Reactions;Adicionar Reações];View Audit Log;Ver Audit Log];View Channel;Ver Canal];Send Messages;Enviar Mensagem];Manage Messages;Gerenciar Mensagem];Embed Links;Inserir Links];Attach Files;Anexar Arquivos];Read Message History;Ver Histórico de Mensagem];Mention Everyone;Mencionar everyone];View Guild Insights;Ver Guild Insights];Connect;Conectar];Speak;Falar];Mute Members;Mutar Membros];Deafen Members;Ensurdecer Membros];Move Members;Mover Membros];Manage Nicknames;Alterar apelido];Manage Roles;Gerenciar Cargos];Manage Webhooks;Criar Webhooks];Manage Emojis;Gerenciar Emojis]\`]
  
  $addField[**Entrada**;
<:data1:834181771658526781>** » Entrou em :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$formatDate[$memberJoinedDate[$mentioned[1;yes]];DD de MMMM YYYY];December;Dezembro de;-1];January;Janeiro de;-1];February;Fevereiro de;-1];March;Março de;-1];April;Abril de;-1];May;Maio de;-1];June;Junho de;-1];July;Julho de;-1];August;Agosto de;-1];September;Setembro de;-1];October;Outubro de;-1];November;Novembro de;-1]\`
<:data:834181766851461120>** » Entrou há :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$memberJoinedDate[$mentioned[1;yes];time];years;anos];year;ano];months;mêses];weeks;semanas];month;mês];days;dias];hours;horas];minutes;minutos];and;é];seconds;segundos];week;semana];day;dia];hour;hora];minute;minuto];second;segundo]\`]

$addField[**Criação**;
<:data1:834181771658526781>** » Criada em :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$formatDate[$CreationDate[$mentioned[1;yes]];DD de MMMM YYYY];December;Dezembro de;-1];January;Janeiro de;-1];February;Fevereiro de;-1];March;Março de;-1];April;Abril de;-1];May;Maio de;-1];June;Junho de;-1];July;Julho de;-1];August;Agosto de;-1];September;Setembro de;-1];October;Outubro de;-1];November;Novembro de;-1]\`
<:data:834181766851461120>** » Criada há :** \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$creationDate[$mentioned[1;yes];time];years;anos];year;ano];months;mêses];weeks;semanas];month;mês];days;dias];hours;horas];minutes;minutos];and;é];seconds;segundos];week;semana];day;dia];hour;hora];minute;minuto];second;segundo]\`]

$addField[**Status**;
<:cafe:834181872756981820>** » Administrador :** \`$ReplaceText[$ReplaceText[$hasPerms[$mentioned[1;yes];admin];true;Sim];false;Não]\`
<:escudo:834418047699648542>** » Apelido:** \`$nickname[$mentioned[1;yes]]\`
<:lapis:834418029525204993>** » Badges :** \`$getUserBadges[$mentioned[1;yes]]\`]

$addField[**Principais**;
<:users:834181871184773140>** » Nome :** \`$username[$mentioned[1;yes]]\`
<:id:834181873944756245>** » ID :** \`$mentioned[1;yes]\`
<:__:834181776545021962>** » Tag :** \`#$discriminator[$mentioned[1;yes]]\`]
  `
}